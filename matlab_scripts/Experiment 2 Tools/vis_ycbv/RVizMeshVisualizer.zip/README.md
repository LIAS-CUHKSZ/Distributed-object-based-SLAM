mkdir -p ws/src

mv RVizMeshVisualizer ws/src

cd src

install:

```
pip install nvdu future yaml
rosdep install --from-paths src --ignore-src -r -y
catkin_make
```

robot轨迹放到trj文件夹，位姿文件放到obj文件夹



要隐藏操作托条和转盘，选择rviz tab栏的camera view（只要不选interact就可以）
