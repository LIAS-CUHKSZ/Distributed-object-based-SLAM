#! /usr/bin/env python3
import os
import rospy
import rospkg
from geometry_msgs.msg import Pose, PoseStamped
from nav_msgs.msg import Path
from interactive_markers.interactive_marker_server import *
from interactive_markers.menu_handler import *
from visualization_msgs.msg import *
from geometry_msgs.msg import Point
from tf.broadcaster import TransformBroadcaster

server = None
br = None
counter = 0

def processFeedback( feedback ):
    s = "Feedback from marker '" + feedback.marker_name
    s += "' / control '" + feedback.control_name + "'"

    mp = ""
    if feedback.mouse_point_valid:
        mp = " at " + str(feedback.mouse_point.x)
        mp += ", " + str(feedback.mouse_point.y)
        mp += ", " + str(feedback.mouse_point.z)
        mp += " in frame " + feedback.header.frame_id

    if feedback.event_type == InteractiveMarkerFeedback.BUTTON_CLICK:
        rospy.loginfo( s + ": button click" + mp + "." )
    elif feedback.event_type == InteractiveMarkerFeedback.MENU_SELECT:
        rospy.loginfo( s + ": menu item " + str(feedback.menu_entry_id) + " clicked" + mp + "." )
    elif feedback.event_type == InteractiveMarkerFeedback.POSE_UPDATE:
        rospy.loginfo( s + ": pose changed")
    elif feedback.event_type == InteractiveMarkerFeedback.MOUSE_DOWN:
        rospy.loginfo( s + ": mouse down" + mp + "." )
    elif feedback.event_type == InteractiveMarkerFeedback.MOUSE_UP:
        rospy.loginfo( s + ": mouse up" + mp + "." )
    server.applyChanges()

def makeBoxControl( msg, name=None):
    control =  InteractiveMarkerControl()
    control.always_visible = True

    marker = Marker()
    marker.type = Marker.MESH_RESOURCE
    marker.mesh_resource = name
    marker.mesh_use_embedded_materials = True
    marker.scale.x = 5.0
    marker.scale.y = 5.0
    marker.scale.z = 5.0

    control.markers.append( marker )
    msg.controls.append( control )
    return control

#####################################################################
# Marker Creation

def make6DofMarker( fixed, interaction_mode, position, show_6dof = False, name=None):
    int_marker = InteractiveMarker()
    int_marker.header.frame_id = "map"
    int_marker.scale = 1
    int_marker.pose = position

    int_marker.name = "simple_6dof" + name
    int_marker.description = "Simple 6-DOF Control"

    # insert a box
    makeBoxControl(int_marker, name)
    int_marker.controls[0].interaction_mode = interaction_mode

    if fixed:
        int_marker.name += "_fixed"
        int_marker.description += "\n(fixed orientation)"

    if interaction_mode != InteractiveMarkerControl.NONE:
        control_modes_dict = { 
                          InteractiveMarkerControl.MOVE_3D : "MOVE_3D",
                          InteractiveMarkerControl.ROTATE_3D : "ROTATE_3D",
                          InteractiveMarkerControl.MOVE_ROTATE_3D : "MOVE_ROTATE_3D" }
        int_marker.name += "_" + control_modes_dict[interaction_mode]
        int_marker.description = "3D Control"
        if show_6dof: 
          int_marker.description += " + 6-DOF controls"
        int_marker.description += "\n" + control_modes_dict[interaction_mode]
    
    if show_6dof: 
        control = InteractiveMarkerControl()
        control.orientation.w = 1
        control.orientation.x = 1
        control.orientation.y = 0
        control.orientation.z = 0
        control.name = "rotate_x"
        control.interaction_mode = InteractiveMarkerControl.ROTATE_AXIS
        if fixed:
            control.orientation_mode = InteractiveMarkerControl.FIXED
        int_marker.controls.append(control)

        control = InteractiveMarkerControl()
        control.orientation.w = 1
        control.orientation.x = 1
        control.orientation.y = 0
        control.orientation.z = 0
        control.name = "move_x"
        control.interaction_mode = InteractiveMarkerControl.MOVE_AXIS
        if fixed:
            control.orientation_mode = InteractiveMarkerControl.FIXED
        int_marker.controls.append(control)

        control = InteractiveMarkerControl()
        control.orientation.w = 1
        control.orientation.x = 0
        control.orientation.y = 1
        control.orientation.z = 0
        control.name = "rotate_z"
        control.interaction_mode = InteractiveMarkerControl.ROTATE_AXIS
        if fixed:
            control.orientation_mode = InteractiveMarkerControl.FIXED
        int_marker.controls.append(control)

        control = InteractiveMarkerControl()
        control.orientation.w = 1
        control.orientation.x = 0
        control.orientation.y = 1
        control.orientation.z = 0
        control.name = "move_z"
        control.interaction_mode = InteractiveMarkerControl.MOVE_AXIS
        if fixed:
            control.orientation_mode = InteractiveMarkerControl.FIXED
        int_marker.controls.append(control)

        control = InteractiveMarkerControl()
        control.orientation.w = 1
        control.orientation.x = 0
        control.orientation.y = 0
        control.orientation.z = 1
        control.name = "rotate_y"
        control.interaction_mode = InteractiveMarkerControl.ROTATE_AXIS
        if fixed:
            control.orientation_mode = InteractiveMarkerControl.FIXED
        int_marker.controls.append(control)

        control = InteractiveMarkerControl()
        control.orientation.w = 1
        control.orientation.x = 0
        control.orientation.y = 0
        control.orientation.z = 1
        control.name = "move_y"
        control.interaction_mode = InteractiveMarkerControl.MOVE_AXIS
        if fixed:
            control.orientation_mode = InteractiveMarkerControl.FIXED
        int_marker.controls.append(control)

    server.insert(int_marker, processFeedback)


#------------------------------------------

if __name__=="__main__":

    rospy.init_node("object_visualizer")
    rospy.loginfo('Initializing object visualizer')
    rp = rospkg.RosPack()
    markerArray = MarkerArray()

    br = TransformBroadcaster()

    server = InteractiveMarkerServer("object_visualizer")
    # publisher = rospy.Publisher('visualization_marker', MarkerArray, queue_size=10)

    # travers the file under package://object_visualizer/obj/ save all file name to obj_list
    # save the trj of each obj, the format of each .csv file is: q0, q1, q2, q3,x,y,z
    obj_list = []
    obj_trj = {}
    obj_folder =  os.path.join(rp.get_path('object_visualizer'), 'obj')

    for file in os.listdir(obj_folder):
        file_name = os.path.splitext(file)[0]  # Remove file extension
        obj_list.append(file_name)
        # read file, the format of each .csv file is: q0, q1, q2, q3, x, y, z there are multiple lines,save to trj_dict
        trj_file = os.path.join(obj_folder, file)
        with open(trj_file, 'r') as file:
            line = file.readline()
            values = line.strip().split(',')
            pose = Pose()
            pose.orientation.x = float(values[1])
            pose.orientation.y = float(values[2])
            pose.orientation.z = float(values[3])
            pose.orientation.w = float(values[0])
            pose.position.x    = float(values[4])*5
            pose.position.y    = float(values[5])*5
            pose.position.z    = float(values[6])*5
            obj_trj[file_name]=pose


    server = InteractiveMarkerServer("dof")

    # find corresponding mesh file in obj_list under package://object_visualizer/meshes/'obj_name'/textured.dae
    # initialize markerArray with all mesh files, set header.frame_id = 'map'
    mesh_foler = os.path.join(rp.get_path('object_visualizer'), 'meshes')
    for obj_name in obj_list:
        path = 'package://object_visualizer/meshes/' + obj_name + '/google_16k/textured.dae'
        position = obj_trj[obj_name]
        make6DofMarker( True, InteractiveMarkerControl.MOVE_ROTATE_3D, position, True, path)
        # marker = Marker()
        # marker.id = obj_list.index(obj_name)
        # marker.mesh_resource = 'package://object_visualizer/meshes/' + obj_name + '/google_16k/textured.dae'
        # marker.mesh_use_embedded_materials = True  # Need this to use textures for mesh
        # marker.type = marker.MESH_RESOURCE
        # marker.header.frame_id = "map"
        # marker.scale.x = 1.0
        # marker.scale.y = 1.0
        # marker.scale.z = 1.0
        # markerArray.markers.append(marker)
        server.applyChanges()
    # traverse the package://ycb_viz/trj folder, read all .csv files
    # save the trj of each robot, the format of each .csv file is: q0, q1, q2, q3, x, y, z, time
    robot_trj = []
    trj_pub = []
    robot_foler = os.path.join(rp.get_path('object_visualizer'), 'trj')
    for i,file in enumerate(os.listdir(robot_foler)):
        trj_file = os.path.join(robot_foler, file)
        trj_pub.append(rospy.Publisher('trj_'+str(i), Path, queue_size=10))
        with open(trj_file, 'r') as file:
            robot_trj.append([])
            lines = file.readlines()
            for line in lines:
                values = line.strip().split(',')
                pose = PoseStamped()
                pose.header.frame_id = 'odom'
                pose.pose.orientation.x = float(values[1])
                pose.pose.orientation.y = float(values[2])
                pose.pose.orientation.z = float(values[3])
                pose.pose.orientation.w = float(values[0])
                pose.pose.position.x    = float(values[4])*5
                pose.pose.position.y    = float(values[5])*5
                pose.pose.position.z    = float(values[6])*5
                pose.header.stamp = rospy.Time(float(values[7]))
                robot_trj[i].append(pose)

    counter = 0
    robot_path = []
    for i in range (len(robot_trj)):
        trj = Path()
        trj.header.frame_id = 'map'
        trj.header.stamp = rospy.Time.now()
        robot_path.append(trj)

    def update_objects(timer_event):
        global counter

        for i in range(len(robot_trj)):
            robot_path[i].header.stamp = rospy.Time.now()
            robot_path[i].poses.append(robot_trj[i][counter])
            trj_pub[i].publish(robot_path[i])

        # for i in range(len(obj_list)):
        #     markerArray.markers[i].pose = obj_trj[obj_list[i]][5]
        # publisher.publish(markerArray)

        counter += 1
        if counter == len(robot_trj[0]):
            t.shutdown()

    t = rospy.Timer(rospy.Duration(0.01), update_objects)

    rospy.spin()

    

    

    # update the position of each object in markerArray according to the trj of each object
    # publish the markerArray and trj of each robot every 0.1s
